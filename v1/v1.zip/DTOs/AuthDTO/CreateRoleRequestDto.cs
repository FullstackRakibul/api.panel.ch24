﻿namespace v1.DTOs.AuthDTO
{
    public class CreateRoleRequestDto
    {
        public string RoleName { get; set; }
        public string? Description { get; set; }
    }
}
