﻿namespace v1.DTOs.AuthDTO
{
    public class AssignRoleRequestDto
    {
        public string UserId { get; set; }
        public string RoleName { get; set; }
    }
}
